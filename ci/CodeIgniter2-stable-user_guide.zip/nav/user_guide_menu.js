function _setNavigation()
{
    myHeight = new Fx.Slide('nav', {duration: 100});
    myHeight.hide();
}